# Contributing to The Privacy Playbook

Thank you for your interest in contributing to The Privacy Playbook! This guide will help you add new privacy guides or improve existing ones.

## How to Contribute

### Adding a New Guide

1. **Fork the repository**
2. **Create a new branch** for your guide
3. **Create a new file** in the `_playbook/` directory

#### Guide Template

Create a new markdown file (e.g., `_playbook/your-guide-name.md`) with this structure:

```yaml
---
layout: post
title: "Your Guide Title"
level: 1  # 1 (Essential), 2 (Intermediate), or 3 (Advanced)
category: Category  # Passwords, Browsing, Communication, Data, or OS
date: YYYY-MM-DD
---

## Why [Topic] Matters

Explain the privacy/security benefit and threat model.

## What is [Topic]

Brief explanation of what the technology or practice is.

## How to [Implement]

### Step 1: [First Step]

Detailed instructions...

### Step 2: [Second Step]

More instructions...

## Best Practices

- Tip 1
- Tip 2
- Tip 3

## Common Issues

### Problem 1

Solution...

## Estimated Time

- Setup: X minutes
- Daily use: Y minutes

## Difficulty

**Level X - [Essential/Intermediate/Advanced]** - Brief explanation of why.

## Next Steps

Link to related guides for progression.
```

### Guide Requirements

#### Content Requirements

- **Clear "Why"**: Explain the privacy benefit and threat model
- **Practical "How"**: Step-by-step instructions that anyone can follow
- **Best Practices**: Security tips and recommendations
- **Time Estimates**: Help users plan
- **Difficulty Assessment**: Be honest about complexity

#### Style Guidelines

- Write for beginners, even for advanced topics
- Use clear, simple language
- Break complex topics into digestible sections
- Include examples where helpful
- Link to related guides
- Avoid jargon or explain it when necessary

#### Technical Guidelines

- Test all instructions before submitting
- Include multiple OS instructions when relevant (Windows, Mac, Linux)
- Provide alternative tools/services when possible
- Keep information current and up-to-date

### Choosing the Right Level

**Level 1 - Essential**
- Basic steps everyone should take
- Minimal technical knowledge required
- High impact with low effort
- Examples: Password managers, 2FA, basic browser settings

**Level 2 - Intermediate**
- Requires some setup and learning
- May involve paid services or lifestyle changes
- Significant privacy improvement
- Examples: VPNs, privacy browsers, encrypted messaging

**Level 3 - Advanced**
- Requires technical knowledge
- Significant time investment
- For users with high threat models
- Examples: Tails OS, PGP encryption, advanced OPSEC

### Choosing the Right Category

- **Passwords**: Authentication, password management, account security
- **Browsing**: Web browsers, browser extensions, web tracking
- **Communication**: Messaging, email, video calls
- **Data**: File storage, backups, encryption at rest
- **OS**: Operating systems, system-level security

## Improving Existing Guides

- Fix typos or errors
- Update outdated information
- Add clarifications
- Improve instructions
- Add new tools or alternatives

## Testing Your Changes

Before submitting:

1. **Run the site locally (static server):**
   ```bash
   python -m http.server 4000
   ```

2. **Check your guide:**
   - Visit `http://localhost:4000`
   - Verify your guide appears correctly
   - Test all links
   - Check formatting

3. **Verify filtering:**
   - Check your level page (e.g., `/level-2/`)
   - Check your category page (e.g., `/category/browsing/`)
   - Ensure your guide appears in both
   - Ensure your guide is added to `assets/data/guides.json`

## Submitting Your Contribution

1. **Commit your changes:**
   ```bash
   git add _playbook/your-guide.md
   git commit -m "Add guide: Your Guide Title"
   ```

2. **Push to your fork:**
   ```bash
   git push origin your-branch-name
   ```

3. **Create a Pull Request:**
   - Go to the original repository
   - Click "New Pull Request"
   - Select your branch
   - Describe your changes

### Pull Request Guidelines

- Use a clear, descriptive title
- Explain what your guide covers
- Mention any related issues
- Be open to feedback and revisions

## Questions or Suggestions?

- Open an issue for discussion
- Tag issues with appropriate labels
- Be respectful and constructive

## Code of Conduct

- Be respectful and inclusive
- Focus on improving privacy education
- Help others learn
- Provide constructive feedback
- Respect different threat models and use cases

## License

By contributing, you agree that your contributions will be licensed under the same license as the project (MIT License).

Thank you for helping make the internet more private and secure! 🔒
