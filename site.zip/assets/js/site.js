(() => {
  const SITE = {
    title: "The Privacy Playbook",
    description: "A comprehensive guide to protecting your privacy and security online",
  };

  const CATEGORY_DISPLAY = {
    Passwords: "Passwords & Authentication",
    Browsing: "Browsing & Internet",
    Communication: "Communication",
    Data: "Data & Storage",
    OS: "Operating Systems",
  };

  const CATEGORY_PATH = {
    Passwords: "category/passwords/",
    Browsing: "category/browsing/",
    Communication: "category/communication/",
    Data: "category/data/",
    OS: "category/os/",
  };

  const $ = (selector, root = document) => root.querySelector(selector);

  function escapeHtml(text) {
    return String(text)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function formatDate(yyyyMmDd) {
    // Treat dates as UTC to avoid shifting in local time zones.
    const date = new Date(`${yyyyMmDd}T00:00:00Z`);
    if (Number.isNaN(date.getTime())) return yyyyMmDd;
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      timeZone: "UTC",
    }).format(date);
  }

  function setActiveNav() {
    const path = window.location.pathname.replace(/\/+$/, "/");
    const basePath = (() => {
      try {
        return new URL(document.baseURI).pathname.replace(/\/+$/, "/");
      } catch {
        return "/";
      }
    })();
    for (const link of document.querySelectorAll(".site-nav a")) {
      let href = "";
      try {
        href = new URL(link.href).pathname.replace(/\/+$/, "/");
      } catch {
        href = (link.getAttribute("href") || "").replace(/\/+$/, "/");
      }
      if (!href || href === "#") continue;
      if (href === basePath && path === basePath) link.classList.add("is-active");
      else if (href !== basePath && path.startsWith(href)) link.classList.add("is-active");
    }
  }

  function guideCardHtml(guide) {
    const categoryDisplay = CATEGORY_DISPLAY[guide.category] || guide.category;
    const categoryHref = CATEGORY_PATH[guide.category] || "/category/";
    return `
      <article class="guide-card">
        <header class="guide-card__header">
          <h3 class="guide-card__title"><a href="${escapeHtml(guide.url)}">${escapeHtml(
      guide.title
    )}</a></h3>
          <div class="guide-card__meta">
            <span class="level-badge level-${escapeHtml(String(guide.level))}">Level ${escapeHtml(
      String(guide.level)
    )}</span>
            <a class="category-badge" href="${escapeHtml(categoryHref)}">${escapeHtml(
      categoryDisplay
    )}</a>
            <time datetime="${escapeHtml(guide.date)}">${escapeHtml(formatDate(guide.date))}</time>
          </div>
        </header>
        <p class="guide-card__excerpt">${escapeHtml(guide.excerpt || "")}</p>
        <p class="guide-card__cta"><a href="${escapeHtml(guide.url)}">Read guide →</a></p>
      </article>
    `;
  }

  function renderGuideList(container, guides) {
    if (!container) return;
    if (!guides.length) {
      container.innerHTML = `<p class="muted">No guides found.</p>`;
      return;
    }
    container.innerHTML = `<div class="guide-list">${guides.map(guideCardHtml).join("")}</div>`;
  }

  function normalizeQuery(q) {
    return String(q || "").trim().toLowerCase();
  }

  function matchesQuery(guide, query) {
    if (!query) return true;
    const haystack = `${guide.title} ${guide.excerpt} ${guide.category} Level ${guide.level}`.toLowerCase();
    return haystack.includes(query);
  }

  async function loadGuides() {
    const res = await fetch("assets/data/guides.json", { cache: "no-store" });
    if (!res.ok) throw new Error(`Failed to load guides: ${res.status}`);
    const guides = await res.json();
    return Array.isArray(guides) ? guides : [];
  }

  function sortByDateDesc(guides) {
    return [...guides].sort((a, b) => String(b.date).localeCompare(String(a.date)));
  }

  async function main() {
    setActiveNav();

    const body = document.body;
    const page = body?.dataset?.page || "";

    if (!page) return;

    const guides = await loadGuides();

    if (page === "home") {
      const latest = sortByDateDesc(guides).slice(0, 5);
      renderGuideList($("#latest-guides"), latest);
      return;
    }

    if (page === "level") {
      const level = Number(body.dataset.level);
      const filtered = guides.filter((g) => Number(g.level) === level);
      renderGuideList($("#guide-list"), sortByDateDesc(filtered));
      return;
    }

    if (page === "category") {
      const category = String(body.dataset.category || "");
      const filtered = guides.filter((g) => String(g.category) === category);
      renderGuideList($("#guide-list"), sortByDateDesc(filtered));
      return;
    }

    if (page === "all") {
      const input = $("#guide-search");
      const list = $("#guide-list");
      const initial = sortByDateDesc(guides);

      const render = () => {
        const query = normalizeQuery(input?.value);
        const filtered = initial.filter((g) => matchesQuery(g, query));
        renderGuideList(list, filtered);
      };

      if (input) input.addEventListener("input", render);
      render();
      return;
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    main().catch((err) => {
      // eslint-disable-next-line no-console
      console.error(err);
      const target = document.querySelector("#guide-list, #latest-guides");
      if (target) target.innerHTML = `<p class="muted">Could not load guides. Try refreshing.</p>`;
    });
  });
})();
