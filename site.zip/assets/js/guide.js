(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const CATEGORY_DISPLAY = {
    Passwords: "Passwords & Authentication",
    Browsing: "Browsing & Internet",
    Communication: "Communication",
    Data: "Data & Storage",
    OS: "Operating Systems",
  };

  const CATEGORY_PATH = {
    Passwords: "category/passwords/",
    Browsing: "category/browsing/",
    Communication: "category/communication/",
    Data: "category/data/",
    OS: "category/os/",
  };

  function stripFrontMatter(markdown) {
    const text = String(markdown || "");
    if (!text.startsWith("---")) return text;
    const lines = text.split(/\r?\n/);
    if (lines[0].trim() !== "---") return text;
    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim() === "---") {
        return lines.slice(i + 1).join("\n").replace(/^\s+/, "");
      }
    }
    return text;
  }

  function rewriteRootRelativeUrls(root) {
    for (const a of root.querySelectorAll('a[href^="/"]')) {
      const href = a.getAttribute("href");
      if (!href) continue;
      a.setAttribute("href", href.replace(/^\/+/, ""));
    }
    for (const img of root.querySelectorAll('img[src^="/"]')) {
      const src = img.getAttribute("src");
      if (!src) continue;
      img.setAttribute("src", src.replace(/^\/+/, ""));
    }
  }

  function markExternalLinks(root) {
    for (const a of root.querySelectorAll('a[href^="http://"], a[href^="https://"]')) {
      a.setAttribute("target", "_blank");
      a.setAttribute("rel", "noopener noreferrer");
    }
  }

  function formatDate(yyyyMmDd) {
    const date = new Date(`${yyyyMmDd}T00:00:00Z`);
    if (Number.isNaN(date.getTime())) return yyyyMmDd;
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      timeZone: "UTC",
    }).format(date);
  }

  async function loadGuides() {
    const res = await fetch("assets/data/guides.json", { cache: "no-store" });
    if (!res.ok) throw new Error(`Failed to load guides metadata: ${res.status}`);
    const guides = await res.json();
    return Array.isArray(guides) ? guides : [];
  }

  function getGuideSlug(path) {
    const match = String(path || "").match(/_playbook\/(.+)\.md$/);
    return match ? match[1] : "";
  }

  function hydrateGuideMeta(guide) {
    if (!guide) return;

    const title = $(".post-title");
    const levelBadge = $(".level-badge");
    const categoryBadge = $(".category-badge");
    const time = $(".post-meta time");
    const description = document.querySelector('meta[name="description"]');

    if (title) title.textContent = guide.title;
    if (levelBadge) {
      levelBadge.textContent = `Level ${guide.level}`;
      levelBadge.className = `level-badge level-${guide.level}`;
    }
    if (categoryBadge) {
      categoryBadge.textContent = CATEGORY_DISPLAY[guide.category] || guide.category;
      categoryBadge.setAttribute("href", CATEGORY_PATH[guide.category] || "playbook/");
    }
    if (time) {
      time.setAttribute("datetime", guide.date);
      time.textContent = formatDate(guide.date);
    }
    if (description) description.setAttribute("content", guide.excerpt || "");

    document.title = `${guide.title} | The Privacy Playbook`;
  }

  async function loadAndRenderMarkdown({ container, path }) {
    const res = await fetch(path, { cache: "no-store" });
    if (!res.ok) throw new Error(`Failed to load guide markdown: ${res.status}`);
    const raw = await res.text();
    const markdown = stripFrontMatter(raw);

    const markedApi = window.marked;
    if (!markedApi || typeof markedApi.parse !== "function") {
      throw new Error("Markdown renderer not available (marked).");
    }

    markedApi.setOptions({
      gfm: true,
      breaks: false,
      headerIds: true,
      mangle: false,
    });

    container.innerHTML = markedApi.parse(markdown);
    rewriteRootRelativeUrls(container);
    markExternalLinks(container);
  }

  document.addEventListener("DOMContentLoaded", () => {
    const container = $("#guide-markdown");
    const path = document.body?.dataset?.md;
    if (!container || !path) return;

    Promise.all([loadGuides(), loadAndRenderMarkdown({ container, path })])
      .then(([guides]) => {
        const slug = getGuideSlug(path);
        hydrateGuideMeta(guides.find((guide) => guide.slug === slug));
      })
      .catch((err) => {
      // eslint-disable-next-line no-console
        console.error(err);
        container.innerHTML = `<p class="muted">Could not load this guide. Try refreshing.</p>`;
      });
  });
})();

