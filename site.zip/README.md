# The Privacy Playbook

A comprehensive guide to protecting your privacy and security online.

## About

The Privacy Playbook provides step-by-step guides to help you protect your privacy online. Guides are organized by:

- **Level** (1-3): From essential basics to advanced techniques
- **Category**: Passwords, Browsing, Communication, Data, Operating Systems

Each guide includes:
- **Why**: Explanation of the privacy/security benefit
- **How**: Step-by-step instructions
- **When**: Appropriate use cases
- Estimated time and difficulty level

## Quick Start

### Run Locally (Static HTML/CSS/JS)

Because the site loads guide metadata and guide Markdown via `fetch()`, you should run it from a local web server (not `file://`).

1. Start a local server from the repo root:

   ```bash
   python -m http.server 4000
   ```

2. Open your browser to `http://localhost:4000`

### Notes

- Guides are rendered client-side from Markdown in `_playbook/`.
- Guide lists and filtering are driven by `assets/data/guides.json`.
- `.nojekyll` is included so GitHub Pages serves this as a plain static site.

## Project Structure

```
.
├── index.html                 # Homepage
├── playbook/                  # All guides page + guide routes
├── level-1/                   # Level 1 filter page
├── level-2/                   # Level 2 filter page
├── level-3/                   # Level 3 filter page
├── category/                  # Category pages (pretty URLs)
├── _playbook/                 # Guide Markdown sources
├── assets/
│   ├── css/style.css          # Theme/styles
│   ├── data/guides.json       # Guide metadata (title/level/category/excerpt)
│   └── js/                    # Client-side rendering (lists + markdown)
└── README.md                  # This file
```

## Adding New Guides

Create a new markdown file in `_playbook/` with the following front matter:

```yaml
---
layout: post
title: "Your Guide Title"
level: 1  # 1 (Essential), 2 (Intermediate), or 3 (Advanced)
category: Passwords  # Passwords, Browsing, Communication, Data, or OS
date: YYYY-MM-DD
---

Your guide content here...
```

Then add an entry to `assets/data/guides.json` so it appears in lists.

## Levels

- **Level 1 - Essential**: Basic measures everyone should take
- **Level 2 - Intermediate**: Additional protection for enhanced privacy
- **Level 3 - Advanced**: Advanced techniques for high-threat scenarios

## Categories

- **Passwords & Authentication**: Password managers, 2FA, security keys
- **Browsing & Internet**: VPNs, privacy browsers, tracking protection
- **Communication**: Encrypted messaging, email security
- **Data & Storage**: File encryption, secure backups
- **Operating Systems**: Privacy-focused OS options

## Contributing

Contributions are welcome! Please feel free to submit pull requests with:
- New privacy guides
- Improvements to existing guides
- Corrections or updates
- Additional categories or levels

## License

This project is open source and available under the MIT License.

## Acknowledgments

- Theme inspired by [Monos](https://github.com/ejjoo/jekyll-theme-monos)
